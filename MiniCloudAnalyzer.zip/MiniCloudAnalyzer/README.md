# Mini Cloud Log Analyzer – Variante D

## Descripción
Este programa analiza códigos HTTP desde stdin y detecta tres errores consecutivos.

## Lógica
Se utiliza un contador que incrementa cuando el código está entre 400 y 599.
Si el contador llega a 3, se detecta la condición.

## Tecnologías
- ARM64 Assembly
- Linux syscalls
- GNU Make

## Ejecución
```
make
make run
```

## Ejemplo
Entrada:
```
200
404
500
503
```

Salida:
```
Tres errores consecutivos detectados
```
