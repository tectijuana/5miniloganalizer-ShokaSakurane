.section .data
msg: .asciz "Tres errores consecutivos detectados\n"

.section .bss
buffer: .skip 16

.section .text
.global _start

_start:
    mov x19, #0          // contadorErrores

loop:

    // read(stdin, buffer, 16)
    mov x0, #0
    ldr x1, =buffer
    mov x2, #16
    mov x8, #63
    svc #0

    cmp x0, #0
    beq exit             // fin archivo

    // convertir ASCII a número (solo 3 dígitos)
    ldr x1, =buffer

    ldrb w2, [x1]
    sub w2, w2, #'0'
    mov w3, #100
    mul w2, w2, w3

    ldrb w3, [x1, #1]
    sub w3, w3, #'0'
    mov w4, #10
    mul w3, w3, w4

    add w2, w2, w3

    ldrb w3, [x1, #2]
    sub w3, w3, #'0'

    add w2, w2, w3
    mov x20, x2          // código final

    // verificar si es error (400–599)
    cmp x20, #400
    blt no_error

    cmp x20, #599
    bgt no_error

    // ES ERROR
    add x19, x19, #1

    cmp x19, #3
    bne loop

    // imprimir mensaje
    mov x0, #1
    ldr x1, =msg
    mov x2, #40
    mov x8, #64
    svc #0

    b exit

no_error:
    mov x19, #0
    b loop

exit:
    mov x0, #0
    mov x8, #93
    svc #0
